from django.apps import AppConfig


class EmbargoedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'embargoed'
